# SysDesk – IT Complaint Register (Android app)

## Option A: Build the APK online (no installs)
1. Create a free GitHub account and a new repository.
2. Upload ALL files of this folder (keep the .github folder).
3. Open the repository's Actions tab. The "Build APK" job runs automatically.
4. When it finishes, open the run and download the "SysDesk-apk" artifact. Unzip it to get app-debug.apk.
5. Copy the APK to your phone, tap it, and allow "Install unknown apps".

## Option B: Build on your computer
Requires Node.js 20+, JDK 17 and Android Studio.
    npm install
    npx cap add android
    npx cap sync android
    npx cap open android
Then in Android Studio: Build > Build APK(s).
